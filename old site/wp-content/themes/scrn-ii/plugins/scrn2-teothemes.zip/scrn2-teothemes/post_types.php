<?php 
add_action('init', 'teo_post_types');
function teo_post_types() {
  $labels = array(
    'name' => 'Portfolio items',
    'singular_name' => 'Portfolio item',
    'add_new' => 'Add',
    'add_new_item' => 'Add a new portfolio item',
    'edit_item' => 'Edit portfolio item',
    'new_item' => 'New portfolio item',
    'all_items' => 'All portfolio items',
    'view_item' => 'View portfolio item details',
    'search_items' => 'Search portfolio item',
    'not_found' =>  'No portfolio item found',
    'not_found_in_trash' => 'No portfolio item in the trash.', 
    'parent_item_colon' => '',
    'menu_name' => 'Portfolio'

  );
  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'show_in_menu' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => true, 
    'hierarchical' => false,
    'menu_position' => null,
    'supports' => array('title', 'editor', 'thumbnail')
  ); 
  
  register_post_type('portfolio',$args);
  register_taxonomy_for_object_type( 'category', 'portfolio' ); 
}
?>