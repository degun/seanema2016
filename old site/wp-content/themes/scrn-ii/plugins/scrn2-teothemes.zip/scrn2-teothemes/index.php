<?php
/**
 * Plugin Name: SCRN II - Custom Post Types and Taxonomies
 * Plugin URI: http://teothemes.com
 * Description: Custom taxonomies and post types for the SCRN II theme
 * Version: 1.0
 * Author: TeoThemes
 * Author URI: http://teothemes.com
 * Text Domain: teo
 * License: GPL3
 */

require_once( plugin_dir_path( __FILE__ ) .'/post_types.php' );